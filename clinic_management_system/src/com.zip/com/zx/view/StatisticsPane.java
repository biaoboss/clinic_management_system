package com.zx.view;

import javax.swing.JPanel;

/**
 * 报表统计面板
 * 
 * @author biao boss
 *
 */
public class StatisticsPane extends JPanel{

}
