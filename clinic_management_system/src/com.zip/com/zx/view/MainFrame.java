package com.zx.view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.zx.util.C3P0Utils;
/**
 * 
 * @author biao boss
 *
 */
public class MainFrame extends JFrame {
    
    
    // 左右面板
    private JPanel leftPane, rightPane;
    //
    private JButton patientInfoBtn, statisticsBtn, analysisBtn, exitBtn;

    private CardLayout cardLayout;
    // 基本信息面板
    ShowBasicInfomationPane showPane;
    // 报表统计面板
    StatisticsPane statisticsPane;
    // 业务分析面板
    BusinessAnalysisPane businessAnalysisPane;

    public MainFrame() {
        C3P0Utils.getConnection();
        this.setTitle("诊所管理系统");
        this.setSize(850, 600);
        this.setLayout(new BorderLayout());
        
        ImageIcon mainIcon = new ImageIcon("./img/clinic.png");
        this.setIconImage(mainIcon.getImage());
        // 面板初始化
        this.initialView();
        // 事件绑定
        this.bindEvent();

        JButton button = new JButton("");
        button.getName();

        this.setLocationRelativeTo(this);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    private void initialView() {

        leftPane = new JPanel();
        JPanel pane = new JPanel(new GridLayout(4, 1, 30, 30));
        
        patientInfoBtn = new JButton("患者接待");
        statisticsBtn = new JButton("报表统计");
        analysisBtn = new JButton("业务分析");
        exitBtn = new JButton("退出系统");
        pane.add(patientInfoBtn);
        pane.add(statisticsBtn);
        pane.add(analysisBtn);
        pane.add(exitBtn);
        leftPane.add(pane);
        this.add(leftPane, BorderLayout.WEST);

        rightPane = new JPanel();
        cardLayout = new CardLayout();
        rightPane.setLayout(cardLayout);
        showPane = new ShowBasicInfomationPane();
        statisticsPane = new StatisticsPane();
        businessAnalysisPane = new BusinessAnalysisPane();
        rightPane.add("1", showPane);
        rightPane.add("2", statisticsPane);
        rightPane.add("3", businessAnalysisPane);
        this.add(rightPane);

    }

    private void bindEvent() {
        this.patientInfoBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.first(rightPane);

            }
        });

        this.statisticsBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.last(rightPane);

            }
        });
        this.analysisBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(rightPane, "2");

            }
        });
        this.exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int result = JOptionPane.showConfirmDialog(MainFrame.this, "确认退出?", "确认", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    System.exit(0);
                }
            }
        });

    }

    public JButton getStatisticsBtn() {
        return statisticsBtn;
    }

    public ShowBasicInfomationPane getShowPane() {
        return showPane;
    }

    public StatisticsPane getStatisticsPane() {
        return statisticsPane;
    }

    
}
