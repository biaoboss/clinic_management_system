package com.zx.view;

import javax.swing.JPanel;

/**
 * 业务分析面板
 * 
 * @author biao boss
 *
 */
public class BusinessAnalysisPane extends JPanel{

}
