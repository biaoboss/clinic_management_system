package com.zx.test;

import java.sql.Connection;

import com.zx.util.C3P0Utils;
import com.zx.view.MainFrame;
public class Test {

    void connectionTest(){
        Connection conn = C3P0Utils.getConnection();
        System.out.println(conn);
    }
    public static void main(String[] args) {
        new MainFrame();
        
    }
}


